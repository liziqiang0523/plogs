from plogs import plogs
log = plogs.logger
log.info('test')
